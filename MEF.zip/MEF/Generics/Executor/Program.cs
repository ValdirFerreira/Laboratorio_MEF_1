﻿using Generics;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Executor
{
    class Program
    {
        private CompositionContainer _container;
        [Import(typeof(IEmail))]
        private IEmail email;

        private Program()
        {
            var catalog = new AggregateCatalog();
            catalog.Catalogs.Add(new AssemblyCatalog(typeof(Program).Assembly));
            catalog.Catalogs.Add(new DirectoryCatalog(@"../../MinhasDLLs"));

            _container = new CompositionContainer(catalog);

            try
            {
                this._container.ComposeParts(this);
            }
            catch (CompositionException compositionException)
            {
                Console.WriteLine(compositionException.ToString());
            }
        }

        static void Main(string[] args)
        {
            var p = new Program();
            Console.WriteLine(p.email.EnviarEmail("Olá Mundo"));
            Console.ReadKey();

        }
    }
}
